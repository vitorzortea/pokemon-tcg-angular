export enum RaridadesValor{
    "Common" = 0 ,
    "Uncommon" = 0.1,
    "Rare" = 0.2,
    "Rare Holo" = 0.4,
    "Rare Holo GX" = 0.6,
    "Rare Holo EX" = 0.7,
    "Rare Holo V" = 0.8,
    "Promo" = 0.9,
    "Rare Ultra" = 1,
};
export type PreviaCarta = {
    image:string;
    alt:string;
    view:boolean;
}
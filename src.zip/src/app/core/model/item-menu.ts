import { ICONES } from "./tipagem";

export type itemMenu = {
    router:string,
    icon:ICONES,
    label:string,
}